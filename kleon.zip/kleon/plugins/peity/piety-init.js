$(".donut-1").peity("donut")
$(".donut-2").peity("donut")
$("span.pie").peity("pie")